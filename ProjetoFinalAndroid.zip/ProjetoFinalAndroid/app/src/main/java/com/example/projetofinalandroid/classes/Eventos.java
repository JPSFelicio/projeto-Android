package com.example.projetofinalandroid.classes;

public class Eventos {

        public String evento;
        public String notes;

        public String getEvento(){return evento;}
        public void setEvento(String evento){this.evento= evento;}

        public String getNotes(){return notes;}
        public void setNotes(String notes){this.notes=notes;}

}
