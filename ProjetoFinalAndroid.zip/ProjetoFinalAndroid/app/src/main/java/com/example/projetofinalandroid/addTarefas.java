package com.example.projetofinalandroid;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projetofinalandroid.classes.ToDo;
import com.example.projetofinalandroid.classes.singletonToDo;

import java.util.Calendar;

public class addTarefas extends AppCompatActivity {

    EditText date;
    DatePickerDialog datePickerDialog;

    private ToDo pessoaTemporaria;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addtarefas);
        pessoaTemporaria = new ToDo();

        // inicia o data picker
        date = (EditText) findViewById(R.id.date);
        // crias um onclick evento no data
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // intancia para receber a data atual ,mes e ano do calendario
                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR); // ano atual
                int mMonth = c.get(Calendar.MONTH); // mes atual
                int mDay = c.get(Calendar.DAY_OF_MONTH); // dia atual
                datePickerDialog = new DatePickerDialog(addTarefas.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // da set ao mes , vlores do mes e do ano no edit text
                                date.setText(dayOfMonth + "/"
                                        + (monthOfYear + 1) + "/" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });


    }
    public void adicionarTarefas(View v)
    {
        EditText EDTNomeTarefa = findViewById(R.id.EDTNomeTarefa);
        EditText EDTNotaTarefa = findViewById(R.id.EDTNotaTarefa);


        pessoaTemporaria.setTarefa(EDTNomeTarefa.getText().toString());
        pessoaTemporaria.setNotas(EDTNotaTarefa.getText().toString());

        singletonToDo ToDos = singletonToDo.getInstance();
        ToDos.adicionarTarefa(pessoaTemporaria);

        pessoaTemporaria = new ToDo();
        EDTNomeTarefa.setText("");
        EDTNotaTarefa.setText("");

    }
    public void mudarActivity(View v)
    {
        Intent in = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(in);
    }
}
