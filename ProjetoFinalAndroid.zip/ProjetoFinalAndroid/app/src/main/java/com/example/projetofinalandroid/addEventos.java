package com.example.projetofinalandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projetofinalandroid.classes.Eventos;
import com.example.projetofinalandroid.classes.ToDo;
import com.example.projetofinalandroid.classes.singletonEventos;

public class addEventos extends AppCompatActivity {

    private Eventos eventoTemporario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addevento);
        eventoTemporario = new Eventos();
    }
    public void adicionarEvento(View v) {
        EditText EDTNomeEventos = findViewById(R.id.EDTNomeEventos);
        EditText EDTNotesEventos = findViewById(R.id.EDTNotesEventos);

        eventoTemporario.setEvento(EDTNomeEventos.getText().toString());
        eventoTemporario.setNotes(EDTNotesEventos.getText().toString());

        singletonEventos eVentos = singletonEventos.getInstance();
        eVentos.adicionarEventos(eventoTemporario);

        eventoTemporario = new Eventos();
        EDTNomeEventos.setText("");
        EDTNotesEventos.setText("");
    }

        public void mudarActivity(View v)
        {
            Intent in = new Intent(getApplicationContext(), MainEvento.class);
            startActivity(in);
        }
}
