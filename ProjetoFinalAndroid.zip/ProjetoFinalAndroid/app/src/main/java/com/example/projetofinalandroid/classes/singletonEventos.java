package com.example.projetofinalandroid.classes;

import java.util.ArrayList;
import java.util.List;

public class singletonEventos {

    private List<Eventos> listaEvents;

    private static final singletonEventos instance = new singletonEventos();

    public singletonEventos() {listaEvents= new ArrayList<>();}

    public static singletonEventos getInstance(){return instance;}

    public List<Eventos> getListaEvents() {
        return listaEvents;
    }

    public void adicionarEventos(Eventos eventos) {listaEvents.add(eventos);}
}

