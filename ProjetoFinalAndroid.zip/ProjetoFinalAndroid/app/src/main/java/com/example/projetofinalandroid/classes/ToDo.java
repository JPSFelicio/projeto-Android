package com.example.projetofinalandroid.classes;

public class ToDo {
    private String tarefa;
    private String notas;
    
    public String getTarefa(){return tarefa;}

    public void setTarefa(String tarefa){this.tarefa = tarefa; }

    public String getNotas(){return notas;}

    public void setNotas(String notas){this.notas = notas; }
}
