package com.example.projetofinalandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;

import com.example.projetofinalandroid.classes.Eventos;
import com.example.projetofinalandroid.classes.ToDo;
import com.example.projetofinalandroid.classes.singletonEventos;
import com.example.projetofinalandroid.classes.singletonToDo;

public class MainEvento extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos);
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarLista();
    }


    private void carregarLista() {

        singletonEventos Events = singletonEventos.getInstance();

        for (Eventos eventos : Events.getListaEvents()) {
            TextView novaTxt = new TextView(getApplicationContext());
            novaTxt.setBackgroundColor(getColor(R.color.white));
            novaTxt.setText(eventos.getEvento());

            LinearLayout listaVisual = findViewById(R.id.listaEventos);
            listaVisual.addView(novaTxt);

            novaTxt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent in = new Intent(getApplicationContext(), descritivoEventos.class);
                    int index = Events.getListaEvents().indexOf(eventos);
                    in.putExtra("index", index);
                    startActivity(in);
                }
            });
        }
    }
    public void mudarActivityAdd(View v) {
        Intent in = new Intent(getApplicationContext(), addEventos.class);
        startActivity(in);
    }

    public void mudarActivityToDo(View v) {
        Intent in = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(in);
    }
}
