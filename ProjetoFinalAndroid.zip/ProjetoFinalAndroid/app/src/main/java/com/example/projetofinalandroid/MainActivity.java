package com.example.projetofinalandroid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.projetofinalandroid.classes.ToDo;
import com.example.projetofinalandroid.classes.singletonToDo;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarLista();
    }


    private void carregarLista() {

        singletonToDo ToDos = singletonToDo.getInstance();

        for (ToDo todo : ToDos.getListaTodo()) {
            TextView novaTxt = new TextView(getApplicationContext());
            novaTxt.setBackgroundColor(getColor(R.color.white));
            novaTxt.setText(todo.getTarefa());

            LinearLayout listaVisual = findViewById(R.id.listaTarefas);
            listaVisual.addView(novaTxt);

            novaTxt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent in = new Intent(getApplicationContext(), descritivoTarefa.class);
                    int index = ToDos.getListaTodo().indexOf(todo);
                    in.putExtra("index", index);
                    startActivity(in);
                }
            });
        }
    }

    public void mudarActivityEventos(View v) {
        Intent in = new Intent(getApplicationContext(), MainEvento.class);
        startActivity(in);
    }

    public void mudarActivityAdd(View v) {
        Intent in = new Intent(getApplicationContext(), addTarefas.class);
        startActivity(in);
    }
}



