package com.example.projetofinalandroid;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projetofinalandroid.classes.Eventos;
import com.example.projetofinalandroid.classes.singletonEventos;


public class descritivoEventos extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_descritivo);
        Intent in = getIntent();
        int index = in.getIntExtra("index",0);

        singletonEventos eventos = singletonEventos.getInstance();
        Eventos todo = eventos.getListaEvents().get(index);

        ((TextView)findViewById(R.id.txtNome)).setText(todo.getNotes());
    }
}

