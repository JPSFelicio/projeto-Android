package com.example.projetofinalandroid;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projetofinalandroid.classes.ToDo;
import com.example.projetofinalandroid.classes.singletonToDo;

public class descritivoTarefa extends AppCompatActivity {
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_descritivo);
        Intent in = getIntent();
        int index = in.getIntExtra("index",0);

        singletonToDo tarefa = singletonToDo.getInstance();
        ToDo todo = tarefa.getListaTodo().get(index);

        ((TextView)findViewById(R.id.txtNome)).setText(todo.getTarefa());
        ((TextView)findViewById(R.id.txtNotas)).setText(todo.getNotas());
    }
}
