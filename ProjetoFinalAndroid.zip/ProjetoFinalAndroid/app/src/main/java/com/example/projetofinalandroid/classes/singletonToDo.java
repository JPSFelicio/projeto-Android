package com.example.projetofinalandroid.classes;

import java.util.ArrayList;
import java.util.List;

public class singletonToDo {
    private List<ToDo> listaTodo;

    private static final singletonToDo instance = new singletonToDo();

    public singletonToDo(){listaTodo = new ArrayList<>();}

    public static singletonToDo getInstance(){return instance;}

    public List<ToDo> getListaTodo(){return listaTodo;}

    public void adicionarTarefa(ToDo tarefa)
    {
        listaTodo.add(tarefa);
    }

}
